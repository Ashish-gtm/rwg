#!/bin/bash

# Stop on first error
set -e

LOGFILE=/var/log/fr24feed_install_dump1090.log
exec > >(tee -a $LOGFILE)

exec 2>&1

if grep -q "^receiver.*dvbt" /etc/fr24feed.ini ; then
    DUMP1090_PATH=$(grep -qE '^\s*path=' /etc/fr24feed.ini | cut -d'=' -f2 | cut -d' ' -f 1)
    DUMP1090FA="/usr/bin/dump1090-fa"
    DUMP1090LINK="/usr/lib/fr24/dump1090"

    if [ "$DUMP1090_PATH" != "" ]; then
        #no action, custom dump1090 path set
        exit 0
    elif [ -e "$DUMP1090FA" ] ; then
        echo "dump1090-fa found, linking to $DUMP1090LINK"
        if [ ! -e $DUMP1090LINK ] || [ "$(readlink -f $DUMP1090LINK)" != "$DUMP1090FA" ]; then
            ln -fs /usr/bin/dump1090-fa /usr/lib/fr24/dump1090 || true
        fi
        exit 0
    elif [ ! -e "${DUMP1090LINK}" ] || [ ! -e "$(readlink -f $DUMP1090LINK)" ]; then
        echo "dump1090 is not found, downloading dump1090-mutability..."

        # to skip any questions from APT
        export DEBIAN_FRONTEND=noninteractive

        echo 'dump1090-mutability dump1090-mutability/auto-start boolean false' | debconf-set-selections -v

        apt-get update -y

        DUMP1090_IF_PRESENT=$(apt-cache search --names-only '^dump1090-mutability.*' | awk '{ print $1 }' | head -n 1)

        apt-get -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" install librtlsdr0 libusb-1.0-0 dirmngr lighttpd wget "$DUMP1090_IF_PRESENT" -y

        if [ "$DUMP1090_IF_PRESENT" == "" ]; then
            # Download and install dump1090-mutability if not present in repository
            wget -O /tmp/dump1090-mutability_1.14_armhf.deb https://github.com/mutability/dump1090/releases/download/v1.14/dump1090-mutability_1.14_armhf.deb
            dpkg -i /tmp/dump1090-mutability_1.14_armhf.deb
            rm -f /tmp/dump1090-mutability_1.14_armhf.deb
        fi

        ln -fs /usr/bin/dump1090-mutability /usr/lib/fr24/dump1090

        lighty-enable-mod dump1090 || true
        service lighttpd force-reload || true
        systemctl enable lighttpd || true
        systemctl start lighttpd || true

        echo "dump1090-mutability is installed. You can always override it in /etc/fr24feed.ini with any other supported driver."
        echo "Web server (aircraft map) at http://YOUR_DEVICE_IP/dump1090 is enabled by default."
    elif grep -q 'START_DUMP1090="yes"' /etc/default/dump1090-mutability ; then
        sed -i 's/START_DUMP1090="yes"/START_DUMP1090="no"/g' /etc/default/dump1090-mutability
        systemctl stop dump1090-mutability || true
    fi
fi
