#!/bin/bash

# Stop on first error
set -e

LOGFILE=/var/log/fr24feed_install_dump978.log
exec > >(tee -a $LOGFILE)

exec 2>&1

if grep -q "^receiver.*uat-fr24" /etc/fr24uat-feed.ini ; then
    DUMP978FR24="/usr/bin/dump978-fr24"

    if [ -e "$DUMP978FR24" ] ; then

        # check if active
        ACTIVE="$(systemctl is-active dump978-fr24)"
        if [ "${ACTIVE}" == "active" ]; then
            exit 0
        fi

        # check if enabled
        ENABLED="$(systmctl is-enabled dump978-fr24)"
        if [ "${ENABLED}" != "enabled" ]; then
            echo "dump978-fr24 service is not enabled! Please enable it before starting the UAT feeder!"
            exit 255
        else
            systemctl start dump978-fr24
        fi
        exit 0
    else
        echo "dump978-fr24 is not found, downloading..."

        # to skip any questions from APT
        export DEBIAN_FRONTEND=noninteractive

        apt-get update -y
        apt-get -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" install dump978-fr24 -y

        systemctl enable dump978-fr24
        systemctl start dump978-fr24
    fi
fi
